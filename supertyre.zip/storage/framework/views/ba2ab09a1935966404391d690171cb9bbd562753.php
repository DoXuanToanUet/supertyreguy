

<?php $__env->startSection('title'); ?>
    Order Booking
<?php $__env->stopSection(); ?>

<?php $__env->startSection('styleplugins'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('assets/back/css/order_booking.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <!-- Page Title-->
<div class="page-title">
    <div class="container">
      <div class="column">
        <ul class="breadcrumbs">
          <li><a href="<?php echo e(route('front.index')); ?>"><?php echo e(__('Home')); ?></a> </li>
          <li class="separator"></li>
          <li>Booking</li>
        </ul>
      </div>
    </div>
  </div>
  <!-- Page Content-->
  <div class="container padding-bottom-3x mb-1">
    <div class="card text-center booking-system-wrapper">
      <div class="card-body booking-system-body">
        <form class="booking-system-form" action="<?php echo e(route('front.checkout.order.submit')); ?>" method="POST">
          <?php echo csrf_field(); ?>
          <!-- <?php echo method_field('post'); ?> -->
          <div class="order-select-body">
            <h4>Booking Appointment</h4>
            <div class="form-group">
              <select name="booking_type" class="form-control" id="exampleFormControlSelect1" required>
                <option value="">Select option</option>
                <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($list->id); ?>">
                        <?php echo e($list->title); ?>

                    </option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </select>
            </div>

            <div class="order-time-select">
              <div class="form-group booking-date-select">
              <i class="fas fa-calendar calender-icon fa-2x" ></i>
                <input type='text' name="booking_date" class="form-control" id='datetimepicker' required />
              </div>
              <div class="form-group">
                <select name="booking_time" class="form-control" id="exampleFormControlSelect1" required>
                  <option value=""> Select time </option>
                  <option value="09:00 AM - 10:00 AM"> 09:00 AM - 10:00 AM </option>
                  <option value="10:00 AM - 11:00 AM"> 10:00 AM - 11:00 AM </option>
                  <option value="11:00 AM - 12:00 PM"> 11:00 AM - 12:00 PM </option>
                  <option value="12:00 PM - 01:00 PM"> 12:00 PM - 01:00 PM </option>
                  <option value="01:00 PM - 02:00 PM"> 01:00 PM - 02:00 PM </option>
                </select>
              </div>
            </div>
          </div>
          <button type="submit" class="booking-btn" >Place Booking</button>
        </form>
      </div>
    </div>
  </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
  <!-- <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/3.3.7/css/bootstrap.min.css"> -->
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datetimepicker/4.7.14/css/bootstrap-datetimepicker.min.css">
  <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.15.1/moment.min.js"></script>
  <!-- <script src="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/3.3.7/js/bootstrap.min.js"></script> -->
  <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datetimepicker/4.7.14/js/bootstrap-datetimepicker.min.js"></script>
  <script type="text/javascript">
    $(function() {
      $('#datetimepicker').datetimepicker({ 
        minDate: new Date(),
        format: 'DD-MM-YYYY'
      });
    });
  </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('master.front', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/guysupertyre/public_html/core/resources/views/front/book_order/booking.blade.php ENDPATH**/ ?>