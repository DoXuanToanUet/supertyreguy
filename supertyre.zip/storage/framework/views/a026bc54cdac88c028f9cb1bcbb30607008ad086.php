
<?php
    $cart = Session::has('cart') ? Session::get('cart') : [];
    $cotal =0;
    $option_price = 0;
    $aditional_value=Session::has('aditional_cost') ? Session::get('aditional_cost') : 0;
?>

<div class="card">
    <div class="card-body">
        <div class="table-responsive shopping-cart">
            <table class="table table-bordered">

              <thead>
                <tr>
                  <th><?php echo e(__('Product Name')); ?></th>
                  <th><?php echo e(__('Product Price')); ?></th>
                  <th class="text-center"><?php echo e(__('Quantity')); ?></th>
                  <th class="text-center"><?php echo e(__('Subtotal')); ?></th>
                  <th class="text-center"><a class="btn btn-sm btn-outline-danger" href="<?php echo e(route('front.cart.clear')); ?>"><?php echo e(__('Clear Cart')); ?></a></th>
                </tr>
              </thead>

              <tbody id="cart_view_load" data-target="<?php echo e(route('cart.get.load')); ?>">
                <?php
                      //  dd($cart);
                ?>
                <?php $__currentLoopData = $cart; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php
                    $cotal += $item['main_price'] * $item['qty'];
                    $option_price += $item['attribute_price'];
                    $cartTotal = $cotal + $option_price;
                ?>
                <tr>
                    <td>
                      <div class="product-item"><a class="product-thumb" href="<?php echo e(route('front.product',$item['slug'])); ?>"><img src="<?php echo e(asset('assets/images/'.$item['photo'])); ?>" alt="Product"></a>
                        <div class="product-info">
                          <h4 class="product-title"><a href="<?php echo e(route('front.product',$item['slug'])); ?>">
                            <?php echo e(strlen(strip_tags($item['name'])) > 45 ? substr(strip_tags($item['name']), 0, 45) . '...' : strip_tags($item['name'])); ?>


                        </a></h4>

                          <?php $__currentLoopData = $item['attribute']['option_name']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $optionkey => $option_name): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          <span><em><?php echo e($item['attribute']['names'][$optionkey]); ?>:</em> <?php echo e($option_name); ?> (<?php echo e(PriceHelper::setCurrencyPrice($item['attribute']['option_price'][$optionkey])); ?>)</span>

                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                      </div>
                    </td>
                    <td class="text-center text-lg"><?php echo e(PriceHelper::setCurrencyPrice($item['main_price'])); ?></td>

                    <td class="text-center">
                     <?php if($item['item_type'] != 'digital'): ?>
                     <div class="count-input">
                      <select class="form-control update_cart_qty" data-target="<?php echo e(PriceHelper::GetItemId($key)); ?>" data-id="<?php echo e($key); ?>" >
                        <option <?php echo e($item['qty'] == 1 ? 'selected' : ''); ?>><?php echo e(__('1')); ?></option>
                        <option <?php echo e($item['qty'] == 2 ? 'selected' : ''); ?>><?php echo e(__('2')); ?></option>
                        <option <?php echo e($item['qty'] == 3 ? 'selected' : ''); ?>><?php echo e(__('3')); ?></option>
                        <option <?php echo e($item['qty'] == 4 ? 'selected' : ''); ?>><?php echo e(__('4')); ?></option>
                        <option <?php echo e($item['qty'] == 5 ? 'selected' : ''); ?>><?php echo e(__('5')); ?></option>
                        <option <?php echo e($item['qty'] == 6 ? 'selected' : ''); ?>><?php echo e(__('6')); ?></option>
                        <option <?php echo e($item['qty'] == 7 ? 'selected' : ''); ?>><?php echo e(__('7')); ?></option>
                        <option <?php echo e($item['qty'] == 8 ? 'selected' : ''); ?>><?php echo e(__('8')); ?></option>
                        <option <?php echo e($item['qty'] == 9 ? 'selected' : ''); ?>><?php echo e(__('9')); ?></option>
                        <option <?php echo e($item['qty'] == 10 ? 'selected' : ''); ?>><?php echo e(__('10')); ?></option>

                      </select>
                    </div>
                     <?php endif; ?>

                    </td>
                    <td class="text-center text-lg"><?php echo e(PriceHelper::setCurrencyPrice($item['main_price'] * $item['qty'])); ?></td>

                    <td class="text-center"><a class="remove-from-cart" href="<?php echo e(route('front.cart.destroy',$key)); ?>" data-toggle="tooltip" title="Remove item"><i class="icon-x"></i></a></td>
                  </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

              </tbody>
            </table>
          </div>
    </div>
</div>


  <div class="card mt-4">
      <div class="card-body">
        <div class="shopping-cart-footer">
            <div class="column">
                <form class="coupon-form" method="post" id="coupon_form" action="<?php echo e(route('front.promo.submit')); ?>">
                <?php echo csrf_field(); ?>
                <input class="form-control form-control-sm" name="code" type="text" placeholder="<?php echo e(__('Coupon code')); ?>" required>
                <button class="btn btn-outline-primary btn-sm" type="submit"><?php echo e(__('Apply Coupon')); ?></button>
                </form>
            </div>

            <div class="text-right text-lg column <?php echo e(Session::has('coupon') ? '' : 'd-none'); ?>"><span class="text-muted"><?php echo e(__('Discount')); ?> (<?php echo e(Session::has('coupon') ? Session::get('coupon')['code']['title'] : ''); ?>) : </span><span class="text-gray-dark"><?php echo e(PriceHelper::setCurrencyPrice(Session::has('coupon') ? round(Session::get('coupon')['discount'],2) : 0)); ?></span></div>

            <div class="text-right column text-lg">
              <div>
                <span class="text-muted"><?php echo e(__('Subtotal')); ?>: </span><span class="text-gray-dark"><?php echo e(PriceHelper::setCurrencyPrice($cartTotal - (Session::has('coupon') ? round(Session::get('coupon')['discount'],2) : 0))); ?></span>
              </div>
              <div>
              <span class="text-muted"><?php echo e(__('GST Price')); ?>: </span><span class="text-gray-dark"><?php echo e(PriceHelper::setCurrencyGSTPrice($cartTotal - (Session::has('coupon') ? round(Session::get('coupon')['discount'],2) : 0))); ?></span>
              </div>
            </div>
            <!-- <div class="text-right column text-lg"><span class="text-muted"><?php echo e(__('GST Price')); ?>: </span><span class="text-gray-dark"><?php echo e(PriceHelper::setCurrencyPrice($cartTotal - (Session::has('coupon') ? round(Session::get('coupon')['discount'],2) : 0))); ?></span></div> -->


        </div>
        <div class="shopping-cart-footer">
            <div class="column"><a class="btn btn-secondary btn-sm" href="<?php echo e(route('front.catalog')); ?>"><i class="icon-arrow-left"></i><?php echo e(__('Back to Shopping')); ?></a></div>
            <div class="column checkout-select">
              <ul>
                <li id="checkoutChecktext"><input type="checkbox" value="28" id="checkoutCheckAll" <?php echo ($aditional_value['All-$28']??"") ? "checked" : ""; ?> ><span >All $28</span></li>
                <li id="checkoutChecktext1"><input type="checkbox" value="10" id="checkoutCheck" <?php echo ($aditional_value['Strip/fit-$10']??"") ? "checked" : ""; ?>><span >Strip/fit $10</span></li>
                <li id="checkoutChecktext2"><input type="checkbox" value="3" id="checkoutCheck" <?php echo ($aditional_value['new-valve-$3']??"") ? "checked" : ""; ?>><span >new valve $3</span></li>
                <li id="checkoutChecktext3"><input type="checkbox" value="10" id="checkoutCheck" <?php echo ($aditional_value['balance-$10']??"") ? "checked" : ""; ?>><span >balance $10</span></li>
                <li id="checkoutChecktext4"><input type="checkbox" value="5" id="checkoutCheck" <?php echo ($aditional_value['tyre-disposal-$5']??"") ? "checked" : ""; ?>><span >tyre disposal $5</span></li>
              </ul>
            </div>
            <div class="column"><a class="btn btn-primary btn-sm" href="<?php echo e(route('front.checkout.billing')); ?>"><?php echo e(__('Checkout')); ?></a></div>
        </div>
      </div>
  </div>
</div>


<?php /**PATH /home/guysupertyre/public_html/core/resources/views/includes/cart.blade.php ENDPATH**/ ?>